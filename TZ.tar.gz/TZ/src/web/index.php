<center> IP, с которого пришел запрос </br> </center>
<center> <?php echo $_SERVER['HTTP_X_REAL_IP']; ?> </center>

<?php phpinfo(); ?>
